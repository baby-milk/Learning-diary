// 请求数据
let data=null;
function send(){
    let xhr=new XMLHttpRequest;
    xhr.open("get",'./json/banner.json',false);
    xhr.onreadystatechange=function(){
        if(xhr.readyState===4 && /^2\d{2}$/.test(xhr.status)){
            data=JSON.parse(xhr.responseText);
        }
    }
    xhr.send();
}
send();
console.log(data);

// 渲染页面
let wrapper=document.getElementById('wrapper');
let pre=document.getElementById('pre');
function bindHtml(data){
    let wrapperHtml="";
    let preHtml="";
    data.forEach((item,index)=>{
        wrapperHtml+=`<li><img src="${item.img}" alt=""></li>`;
        preHtml+=`<li></li>`;
    });
    wrapperHtml+=`<li><img src="${data[0].img}" alt=""></li>`;
    wrapper.innerHTML=wrapperHtml;
    pre.innerHTML=preHtml;
}
bindHtml(data);


// 加入动画
step=0;
function move(num){
    typeof num ==="undefined" ?step++:step=num;
    if(step>=data.length+1){
        wrapper.style.left='0px';
        step=1;
    }
    show();
    utils.animate(wrapper,{left:step*-600},200);
}
let timer=setInterval(move,1000);


// 鼠标移入移出停止，触发
let outer=document.getElementById("outer");
outer.onmouseover=function(){
    clearInterval(timer);
}
outer.onmouseout=function(){
    timer=setInterval(move,1000);
}


// 圆点高亮显示
let list=pre.getElementsByTagName("li");
function show(){
    for(let i=0;i<list.length;i++){
        if(step===i){
            list[i].classList.add('active');
        }else{
            list[i].classList.remove('active');
        }
    }
    if(step===5){
        list[0].classList.add('active');
    }
}
show();

// 点击焦点,图片跟随
function follow(){
    for(let i=0;i<list.length;i++){
        function fun(){
            move(i);
        }
        let res=utils.debounce(fun,50);
        list[i].onclick=res;
    }
}
follow();


//点击两侧，图片偏移
let as=document.getElementsByTagName('a');
function arrows(){
    for(let i=0;i<as.length; i++){
        if(i===0){
            as[i].onclick=function(){
                step--;
                if(step<0){
                  wrapper.style.left = data.length*-600 + 'px';
                  step = data.length-1;
                }
                move(step);
            }
        }else{
            as[i].onclick=function(){
               move();
            }
        }
    }
}
arrows();

