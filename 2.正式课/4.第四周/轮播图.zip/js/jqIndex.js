let swiper=(function(){
    let data=null;
    let step=0;
    let timer=null;
    let $outer=$("#outer");
    let $wrapper=$("#wrapper");
    let $pre=$("#pre");
    let $arrow=$("a");
    let send=()=>{
        $.ajax({
            url:'./json/banner.json',
            type:'get',
            async:false,
            success:(info)=>{
                data=info;
                console.log(data);
            }
        })
    }

    // 渲染页面
    let bindHtml=(data)=>{
        let wrapperHtml='';
        let preHtml='';
        $.each(data,(index,item)=>{
            wrapperHtml+=`<li><img src="${item.img}" alt=""></li>`;
            preHtml+=`<li></li>`;
        })
        wrapperHtml+=`<li><img src="${data[0].img}" alt=""></li>`;
        $wrapper.html(wrapperHtml);
        $pre.html(preHtml);
    }

    // 实现动画
    let move=(num)=>{
        typeof num === 'undefined'?step++:step=num;
        if(step>=data.length+1){
            step=1;
            $wrapper.css('left',0);
        }
        light();
        $wrapper.animate({left:step*-600},"linear");
    }


    // 鼠标悬浮停止，离开继续
    let mouse=()=>{
        $outer.mouseover(()=>{
            clearInterval(timer);
        });
        $outer.mouseout(()=>{
            timer=setInterval(move,1000);
        });
    }


    // 圆点高亮映射
    let light=()=>{
        let index=step;
        if(index===data.length){
            index=0;
        }
        $pre.children("li").eq(index).addClass("active").siblings().removeClass("active");
    }


    // 点击圆点映射
    let focus=()=>{
        let fun=function(){
            move($(this).index());
            console.log($(this).index());
        }
        let res=utils.debounce(fun,50);
        $pre.children("li").click(res);
    }

    // 左右箭头实现切换
    let arrows=()=>{
        $arrow.eq(0).click(()=>{
            step--;
            if(step<0){
                step=data.length-1;
                $wrapper.css("left",data.length*-600);
            }
            move(step);
        })
        $arrow.eq(1).click(()=>{
            move();
        })
    }


    return {
        init:()=>{
            send();
            bindHtml(data);
            light();
            timer=setInterval(move,1000);
            mouse();
            focus();
            arrows();
        }
    }
})();
swiper.init();