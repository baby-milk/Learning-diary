let outer=document.getElementById("outer");
let wrapper=document.getElementById("wrapper");
let pre=document.getElementById("pre");

// 请求数据
let data=null;
function send(){
    let xhr=new XMLHttpRequest;
    xhr.open('get','./json/banner.json',false);
    xhr.onreadystatechange=function(){
        if(xhr.readyState===4 && /^2\d{2}$/.test(xhr.status)){
            data=JSON.parse(xhr.responseText);
        }
    }
    xhr.send();
}
send();
console.log(data);

function bindHtml(){
    let items="";
    let focus="";
    data.forEach((item,index)=>{
        items+=`<li><img src='${item.img}' alt=''></li>`;
        focus+=` <li></li> `;
    });
    items+=`<li><img src='${data[0].img}' alt=''></li>`;
    console.log(items,focus);
    wrapper.innerHTML=items;
    pre.innerHTML=focus;
}
bindHtml();

// 自动轮播
let step=0;
let autoMove= (n)=>{
    typeof n==="undefined" ?step++:step=n;
    if(step===data.length+1){
        wrapper.style.left="0px";
        step=1;
    }
    changeTip();

    utils.animate(wrapper,{left:step*-600},200);
}

let timer=setInterval(autoMove,1000);

// 鼠标划上停止轮播,继续轮播
outer.onmouseenter=function(){
    clearInterval(timer);
}
outer.onmouseleave=function(){
    timer= setInterval(autoMove,1000);
}


// 焦点跟随
let list=pre.getElementsByTagName('li');
let changeTip=()=>{
    // 循环所有焦点，拿每一个焦点的索引和当前的step比较，相等就给焦点加上active类名，吧其余的类名active清除
    for(let i=0;i<list.length;i++){
        if(step===i){
            list[i].classList.add('active');
        }else{
            list[i].classList.remove('active');;
        }
    }
    if(step===5){
        list[0].classList.add('active');
    }
}
changeTip();



// 点击焦点，实现图片跟随

let focus=()=>{
    for(let i=0;i<list.length;i++){
        function fn(){
            autoMove(i);
        }
        let lazyFun=utils.debounce(fn,50);
        list[i].onclick=lazyFun;
    }
}
focus();
