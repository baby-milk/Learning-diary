// let send = () => {
//     $.ajax({
//         url: './json/banner.json', // 请求路径
//         type: 'get', // 请求方式
//         async: false, // 是否异步
//         success: (data) => {
//             // 当你的请求成功以后，当前函数就会执行,并且会把请求回来的数据以实参的形式传递给当前函数
//             console.log(data);
//             newData=data;
//             bindHtml(data);
//             setInterval(move,1000);
//         }
//     })
// }
// 请求数据
let data=null;
function send(){
    let xhr=new XMLHttpRequest;
    xhr.open("get",'./json/banner.json',false);
    xhr.onreadystatechange=function(){
        if(xhr.readyState===4 && /^2\d{2}$/.test(xhr.status)){
            data=JSON.parse(xhr.responseText);
        }
    }
    xhr.send();
}
send();


// 渲染页面
let $wrapper=$("#wrapper");
let $pre=$("#pre");
function bindHtml(data) {
    let wrapperHtml="";
    let preHtml="";
    $(data).each((index,item)=>{
        wrapperHtml+=`<li><img src="${item.img}" alt=""></li>`;
        preHtml+=`<li></li>`;
    })
    wrapperHtml+=`<li><img src="${data[0].img}" alt=""></li>`;
    $wrapper.html(wrapperHtml);
    $pre.html(preHtml);
}
bindHtml(data);


// 开始轮播动画
let step=0;
function move(num){
    typeof num === 'undefined' ? step++:step=num;
    
    if(step>=data.length+1){
        step=1;
        $wrapper.css("left","0px");
    }
    console.log(step);
    show();
    // $wrapper.animate({left:step*-600},1000);
    utils.animate(wrapper,{left:step*-600},200);
}

let timer=setInterval(move,1000);


// 鼠标移入移出，停止继续
$('#outer').on("mouseover",function(){
    clearInterval(timer);
});
$('#outer').on("mouseout",function(){
    timer=setInterval(move,1000);
});



// 圆点映射图片
let $list=$('#pre li');
function show(){
    for(let i=0;i<$list.length;i++){
        if(step===i){
            $list.eq(i).addClass("active");
        }else{
            $list.eq(i).removeClass("active");
        }
    }
    if(step===5){
        $list.eq(0).addClass("active");
    }
}

show();

// 鼠标点击圆点，映射图片
function follow(){
    for(let i=0;i<$list.length;i++){
        function fun(){
            move(i);
        }
        let res=utils.debounce(fun,50);
        $list.eq(i).on("click",res);
    }
}
follow();


//点击两侧，图片偏移
let $as=$("a");
function arrows(){
    for(let i=0;i<$as.length; i++){
        if(i===0){
            $as.eq(i).click(function(){
                step--;
                if(step<0){
                    step=4;
                  }
                move(step);
            })
        }else{
            $as.eq(i).click(function(){
                step++;
              move(step);
            })
        }
    }
}
arrows();